from django.contrib.auth import (
	login, 
	authenticate, 
	logout, 
	update_session_auth_hash
)

from django.contrib.auth.forms import (
	UserCreationForm, 
	UserChangeForm, 
	PasswordChangeForm
)

from django.contrib.auth.models import User
from django.contrib import messages
from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from django.views.generic import View, TemplateView
from django.core.mail import send_mail
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.template.loader import get_template
from .utils import render_to_pdf

from .forms import (
	SignUpForm, 
	EditProfileForm, 
	ContactForm, 
	SurveyForm, 
	ToDoListForm,
	automatedocuments,
)

from pbc.models import Survey, ToDoList

def home(request):
	return render(request, 'pbc/home.html')

def signup(request):
	if request.method == 'POST':
		form = SignUpForm(request.POST)
		if form.is_valid():
			form.save()
			#return redirect('/pbc/login')
			return redirect('/pbc/profile')
	else:
		form = SignUpForm()
		args = {'form': form}
		return render(request, 'pbc/signup.html', args)

def user_login(request):
	context = {}
	if request.method == "POST":
		username = request.POST['username']
		password = request.POST['password']
		user = authenticate(request, username=username, password=password)
		if user:
			login(request, user)
			#return render(request, 'pbc/profile.html')
			messages.success(request, 'Welcome back!')
			return redirect('/pbc/profile')
		else:
			context["error"] = "Username or password is incorrect"
			return render(request, "pbc/login.html", context)
	else:
		return render(request, 'pbc/login.html', context)


	
class automatedocs(TemplateView):
	template_name = 'pbc/automatedocs.html'
	template_pdf = 'pbc/pdffile.html'

	def get(self, request):
		form = SurveyForm()
		return render(request, self.template_name, {'form': form})

	def post(self, request):
		form = SurveyForm(request.POST)
		if form.is_valid():
			survey = form.save(commit=False)
			survey.user = request.user
			survey.save()
			sector = form.cleaned_data['sector'],
			company = form.cleaned_data['company'], 
			name = form.cleaned_data['name'],
			employees_number = form.cleaned_data['employees_number'],
			data_type = form.cleaned_data['data_type'],
			date = form.cleaned_data['date'],
			DPO = form.cleaned_data['DPO'],
			#return redirect

		template = get_template('pbc/pdffile.html')
		args = {'form': form, 'sector':sector, 'company': company,
		'name': name, 'employees_number': employees_number,'data_type': data_type, 'date': date,
		'DPO': DPO}
		html = template.render(args)
		pdf = render_to_pdf('pbc/pdffile.html', args)
		if pdf:
			response = HttpResponse(pdf, content_type='application/pdf')
			filename = "PrivacyByChoice_%s.pdf" %("1")
			content = "inline; filename='%s'" %(filename)
			download = request.GET.get("download")
			if download:
				content = "attachment; filename='%s'" %(filename)
			response['Content-Disposition'] = content
			return response
		return HttpResponse("Not Found")



	


@login_required
def view_profile(request):
	args = {'user': request.user}
	user = request.user
	todolists = ToDoList.objects.filter(user=user)
	args = {'user': user, 'todolists': todolists}
	return render(request, 'pbc/profile.html', args)

@login_required
def edit_profile(request):
	if request.method == 'POST':
		form = EditProfileForm(request.POST, instance=request.user)

		if form.is_valid():
			form.save()
			return redirect('/pbc/profile')
	else:
		form = EditProfileForm(instance=request.user)
		args = {'form': form}
		return render(request, 'pbc/edit_profile.html', args)

@login_required
def change_password(request):
	if request.method == 'POST':
		form = PasswordChangeForm(data=request.POST, user=request.user)

		if form.is_valid():
			form.save()
			update_session_auth_hash(request, form.user)
			return redirect('/pbc/profile')
		else:
			return redirect('/pbc/change-password')
	else:
		form = PasswordChangeForm(user=request.user)
		args = {'form': form}
		return render(request, 'pbc/change_password.html', args)


class SurveyView(TemplateView):
	template_name = 'pbc/survey.html'
	template_pdf = 'pbc/pdffile.html'
	#requirements_template = 'pbc/requirements.html'
	recommendation_template = 'pbc/userrecommendation.html'

	def get(self, request):
		form = SurveyForm()
		user = request.user
		if Survey.objects.filter(user=user):
			surveys = Survey.objects.filter(user=user)
			args = {'surveys': surveys }
			return render(request, self.recommendation_template, args)
		else:
			return render(request, self.template_name, {'form': form})

	def post(self, request):
		form = SurveyForm(request.POST)
		if form.is_valid():
			survey = form.save(commit=False)
			survey.user = request.user
			survey.save()
			sector = form.cleaned_data['sector'],
			company = form.cleaned_data['company'], 
			name = form.cleaned_data['name'],
			employees_number = form.cleaned_data['employees_number'],
			data_type = form.cleaned_data['data_type'],
			date = form.cleaned_data['date'],
			DPO = form.cleaned_data['DPO'],
			#return redirect

		template = get_template('pbc/pdffile.html')
		args = {'form': form, 'sector':sector, 'company': company,
		'name': name, 'employees_number': employees_number,'data_type': data_type, 'date': date,
		'DPO': DPO}
		html = template.render(args)
		pdf = render_to_pdf('pbc/pdffile.html', args)
		if pdf:
			response = HttpResponse(pdf, content_type='application/pdf')
			filename = "PrivacyByChoice_%s.pdf" %("1")
			content = "inline; filename='%s'" %(filename)
			download = request.GET.get("download")
			if download:
				content = "attachment; filename='%s'" %(filename)
			response['Content-Disposition'] = content
			return response
		return HttpResponse("Not Found")

@login_required
def requirements(request):
	solicitor_temp = 'pbc/solicitorrecommendation.html'
	dental_temp = 'pbc/dentalrecommendation.html'
	GP_temp = 'pbc/GPrecommendation.html'
	requirements_temp = 'pbc/requirements.html'

	args = {'user': request.user}
	user = request.user
	#surveyresults = Survey.objects.filter(user=user)
	if Survey.objects.filter(sector__contains='Solicitor', user=user):
		solicitorresult = Survey.objects.filter(sector__contains='Solicitor', user=user)
		print(solicitorresult, "this is solicitor recommendation")
		args = {'solicitorresult': solicitorresult}
		return render(request, 'pbc/solicitorrecommendation.html', args)

	elif Survey.objects.filter(sector__contains='Dental', user=user):
		dentalresult = Survey.objects.filter(ssector__contains='Dental', user=user)
		print(dentalresult, "this is dental recommendation")
		args = {'dentalresult': dentalresult}
		return render(request, 'pbc/dentalrecommendation.html', args)

	elif Survey.objects.filter(sector__contains='GP', user=user):
		GPresult = Survey.objects.filter(sector__contains='GP', user=user)
		print(GPresult, "this is GP recommendation")
		args = {'GPresult': GPresult}
		return render(request, 'pbc/GPrecommendation.html', args)

	else:
		otherresult = Survey.objects.filter(sector__contains='Other', user=user)
		print(otherresult, "this is 'other' recommendation")
		return render (request, 'pbc/requirements.html')


class outputdocument(View):
	def get(self, request, *args, **kwargs):
		template = get_template('pbc/pdffile.html')
		context = {'form': form, 'sector':sector, 'company': company,
		'name': name, 'employees_number': employees_number,'data_type': data_type, 'date': date,
		'DPO': DPO}	
		html = template.render(context)
		pdf = render_to_pdf('pbc/requirements.html', context)
		if pdf:
			return HttpResponse(pdf, content_type='application/pdf')
		return HttpResponse("Not Found")

class GeneratePDF(View):
	def get(self, request, *args, **kwargs):
		template = get_template('pbc/pdffile.html')
		context = {
			'patient_name': 'Tracy Sweeney',
			'date':'20/04/2020',
			'Address': '205 botanic road, Glasnevin',
			'phone_number': '01-8501706',
			'company': 'Village Medical Centre',
			'sector': 'GP'
		}		

		html = template.render(context)
		pdf = render_to_pdf('pbc/pdffile.html', context)
		if pdf:
			response = HttpResponse(pdf, content_type='application/pdf')
			filename = "PrivacyByChoice_%s.pdf" %("1")
			content = "inline; filename='%s'" %(filename)
			download = request.GET.get("download")
			if download:
				content = "attachment; filename='%s'" %(filename)
			response['Content-Disposition'] = content
			return response
		return HttpResponse("Not Found")

@login_required
def requirements_old(request, self):
	solicitor_temp = 'pbc/solicitorrecommendation.html'
	dental_temp = 'pbc/dentalrecommendation.html'
	GP_temp = 'pbc/GPrecommendation.html'
	requirements_temp = 'pbc/requirements.html'

	surveyresults = Survey.objects.filter(user=user)
	if surveyresults.objects.filter(sector__contains='Solicitor'):
		solicitorresult = surveyresults.objects.filter(sector__contains='Solicitor')
		args = {'solicitorresult': solicitorresult}
		return render(request, self.solicitor_temp, args)

	elif surveyresults.objects.filter(sector__contains='Dental'):
		dentalresult = surveyresults.objects.filter(sector__contains='Dental')
		args = {'dentalresult': dentalresult}
		return render(request, self.dental_temp, args)

	elif surveyresults.objects.filter(sector__contains='GP'):
		GPresult = surveyresults.objects.filter(sector__contains='GP')
		args = {'GPresult': GPresult}
		return render(request, self.GP_temp, args)

	else:
		return render (request, self.requirements_temp)


def products(request):
	return render (request, 'pbc/Products.html')


def contact(request):
	if request.method == 'POST':
		form = ContactForm(request.POST)
		if form.is_valid():
			first_name = form.cleaned_data.get('first_name')
			last_name = form.cleaned_data.get('last_name')
			company = form.cleaned_data.get('company')
			email = form.cleaned_data.get('email')
			message = "{0} from has sent you a new message:\n\n{1}".format(first_name, form.cleaned_data.get('message'))
			send_mail('New query', message, email, ['tracy.sweeney7@mail.dcu.ie'])
			messages.success(request, 'Thanks for your query, a member of our team will get back to you as soon as possible')
			return render(request, 'pbc/contact.html')
	else:
		form = ContactForm()		
	return render(request, 'pbc/contact.html', {'form': form})

class GeneralView(View):
	temp_name = 'pbc/general.html'
	def get(self, request):
		form = ToDoListForm()
		user = request.user
		surveys = Survey.objects.filter(user=user)
		#todolists = ToDoList.objects.all
		todolists = ToDoList.objects.filter(user=user)
		args = {'form': form, 'surveys': surveys, 'todolists': todolists}
		return render(request, self.temp_name, args)

	def post(self, request):
		form = ToDoListForm(request.POST)
		user = request.user
		surveys = Survey.objects.filter(user=user)
		if form.is_valid():
			todolist = form.save(commit=False)
			todolist.user = request.user
			todolist.save()
			#todolists = ToDoList.objects.all
			todolists = ToDoList.objects.filter(user=user)
			list_name = form.cleaned_data['name']
			text = form.cleaned_data['text']
			form = ToDoListForm()
			messages.success(request, ('Added to list!'))
		args = {'form': form,'surveys': surveys, 'todolists': todolists}
		return render(request, self.temp_name, args)

@login_required
def delete(request, todolist_id):
	item = ToDoList.objects.get(pk=todolist_id)
	item.delete()
	messages.success(request, ('Deleted from list!'))
	return redirect('/pbc/profile/general')

@login_required
def training(request):
	return render(request, 'pbc/training.html')

@login_required
def upgrade_package(request):
	return render(request, 'pbc/upgrade_package.html')


def alltodolist(request, id):
	ls = ToDoList.objects.get(id=id)

	if request.method == "POST":
		print(request.POST)
		if request.POST.get("save"):
			for item in ls.item_set.all():
				if request.POST.get('c'+str(item.id)=="clicked"):
					item.complete = True
				else:
					item.complete = False

				item.save()


		elif request.POST.get("newItem"):
			txt = request.POST.get("new")

			if len(txt) > 2:
				ls.item_set.create(text=text, complete=False)
			else:
				print("invalid")


	return render(request, 'pbc/upgrade_package.html', {'ls': ls})

def gprecommendation(request):
	return render (request, 'pbc/gprecommendation.html')

def dentalrecommendation(request):
	return render (request, 'pbc/dentalrecommendation.html')

def solicitorrecommendation(request):
	return render (request, 'pbc/solicitorrecommendation.html')

def overviewofgdpr(request):
	return render (request, 'pbc/overviewofgdpr.html')

def rolesandresponsbilities(request):
	return render (request, 'pbc/rolesandresponsbilities.html')

def medicaldata(request):
	return render (request, 'pbc/medicaldata.html')

def personaldata(request):
	return render (request, 'pbc/personaldata.html')

def databreach(request):
	return render (request, 'pbc/databreach.html')


#def upgrade_package(request):
#	if request.method == "POST":
#		form = CreateListForm(request.POST)
#
#		if form.is_valid():
#			n = form.cleaned_data["name"]
#			t = ToDoList(name=n)
#			t.save()
#
#		return HttpResponseRedirect('/%i' %t.id)
#	else:
#		form = CreateListForm()
#
#	return render(request, 'pbc/upgrade_package.html', {'form': form})




#def survey(request,*args, **kwarg):
#	submitbutton = request.POST.get("submit")
#	#if request.method == 'POST':
#		#form = SurveyForm(request.POST)
#	sector =''
#	company = ''
#	name = ''
#	employees_number = ''
#	data_type = ''
#	date = ''
#	DPO = ''
#
#	form = SurveyForm(request.POST or None)
#	if form.is_valid():
#		sector = form.cleaned_data['sector'],
#		company = form.cleaned_data['company'], 
#		name = form.cleaned_data['name'],
#		employees_number = form.cleaned_data['employees_number'],
#		data_type = form.cleaned_data['data_type'],
#		date = form.cleaned_data['date'],
#		DPO = form.cleaned_data['DPO'],
#		#pdf = render_to_pdf('pbc/pdffile.html')
#		#if pdf:
#			#return HttpResponse(pdf,{'form': form}, form_type='application/pdf')
#		return render(request, 'pbc/pdffile.html', {'form': form, 'sector':sector, 'company': company,
#		'name': name, 'employees_number': employees_number,'data_type': data_type, 'date': date,
#		'DPO': DPO})	
#	else:
#		form = SurveyForm()
#	return render(request, 'pbc/survey.html',  {'form': form, 'sector':sector, 'company': company,
#		'name': name, 'employees_number': employees_number,'data_type': data_type, 'date': date,
#		'DPO': DPO})

#def upload_files(request):
	#if request.method == 'POST':
		#form = UploadGDPRfileform(request.POST, request.FILES)
		#if form.is_valid():
			#handle_uploaded_file(request.POST, request.FILES['file'])
			#return HttpResponseRedirect('success/url/')
		#else:
			#form = UploadGDPRfileform()
		#return render(request, 'fileupload.html', {'form': form})

#def sector_recommendation(request):
	#if form.is_valid():
		#sector = form.cleaned_data['sector'],


#class SurveyView(TemplateView):
#	template_name = 'pbc/survey.html'
#	template_pdf = 'pbc/pdffile.html'
#
#	def get(self, request):
#		form = SurveyForm()
#		return render(request, self.template_name, {'form': form})
#
#	def post(self, request):
#		form = SurveyForm(request.POST)
#		if form.is_valid():
#			survey = form.save(commit=False)
#			survey.user = request.user
#			survey.save()
#			sector = form.cleaned_data['sector'],
#			company = form.cleaned_data['company'], 
#			name = form.cleaned_data['name'],
#			employees_number = form.cleaned_data['employees_number'],
#			data_type = form.cleaned_data['data_type'],
#			date = form.cleaned_data['date'],
#			DPO = form.cleaned_data['DPO'],
#			#return redirect
#
#		template = get_template('pbc/pdffile.html')
#		args = {'form': form, 'sector':sector, 'company': company,
#		'name': name, 'employees_number': employees_number,'data_type': data_type, 'date': date,
#		'DPO': DPO}
#		html = template.render(args)
#		pdf = render_to_pdf('pbc/pdffile.html', args)
#		if pdf:
#			response = HttpResponse(pdf, content_type='application/pdf')
#			filename = "PrivacyByChoice_%s.pdf" %("1")
#			content = "inline; filename='%s'" %(filename)
#			download = request.GET.get("download")
#			if download:
#				content = "attachment; filename='%s'" %(filename)
#			response['Content-Disposition'] = content
#			return response
#		return HttpResponse("Not Found")
		#return render(request, self.template_name, args)
		#return render(request, self.template_pdf, args)

#def upgrade_package(request, id):
#	ls = ToDoList.objects.get(id=id)
#	return render(request, 'pbc/upgrade_package.html', {'ls': ls})


#@login_required
#def general(request):
#	user = request.user
#	print(user)
#	#surveys = Survey.objects.all()
#	surveys = Survey.objects.filter(user=user)
#	args = {'surveys': surveys}
#	return render(request, 'pbc/general.html', args)
