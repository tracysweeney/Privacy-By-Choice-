from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.contrib.auth.models import User
from .models import Survey, ToDoList

class SurveyForm(forms.ModelForm):
    sector = forms.ChoiceField(label='What sector are you an employee of?', choices=[('Solicitor Practice', 'Solicitor Practice'), ('Dental Practice', 'Dental Practice'), ('GP Practice', 'GP Practice'), ('Other', 'Other', )], required=True)
    company = forms.CharField(label='What is the name of the company you work for?', max_length=100, required=True)
    name = forms.CharField(label='What is your name?', max_length=100, required=True)
    employees_number = forms.CharField(label='How many employees work at your company?', max_length=100, required=True)
    data_type = forms.CharField(label='What type of data do you collect?', max_length=100,required=True)
    date = forms.CharField(label='What date is this document for?', max_length=100,required=True)
    DPO = forms.ChoiceField(label='Do you have a Data Protection Officer (DPO)', choices=[('Yes', 'Yes'), ('No', 'No'),], required=True)
    #valid_purpose = forms.Charfield(label='Do you have a valid purpose for obtaining this data? If so, have your customers given consent to their data being used for this purpose?', max_length=100,required=True)
    class Meta:
        model = Survey
        fields = (
            'sector', 
            'company',
            'name',
            'employees_number',
            'data_type', 
            'date',
            'DPO', 
            #'valid_purpose'
        )

class automatedocuments(forms.Form):
    company_name = forms.CharField(label='What is the name of the company you work for?', max_length=100, required=True)
    date = forms.CharField(label='What date is this document for?', max_length=100,required=True)

class SignUpForm(UserCreationForm):
    email = forms.EmailField(required=True)    
    company = forms.CharField(max_length=254, required=False)
    username = forms.CharField(max_length=254, required=False)  
    
    class Meta:
        model = User
        fields = (
            'username',
            'first_name', 
            'last_name', 
            'email',
            'company', 
            'password1', 
            'password2'
        )

    def save(self, commit=True):
        user = super(SignUpForm, self).save(commit=False)
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        user.email = self.cleaned_data['email']
        user.company = self.cleaned_data['company']

        if commit:
            user.save()

        return user



class ContactForm(forms.Form):
    first_name = forms.CharField(max_length=30, required=False,) 
    last_name = forms.CharField(max_length=30, required=False, )
    company = forms.CharField(max_length=30, required=False,)
    email = forms.EmailField(max_length=30, required=False,)
    message = forms.CharField(widget=forms.Textarea, max_length=30, required=False)

class EditProfileForm(UserChangeForm):

    class Meta:
        model = User
        fields = (
                'email',
                'first_name',
                'last_name',
                'password'
            )

class ToDoListForm(forms.ModelForm):
    name = forms.CharField(max_length=200, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'To-Do List Title'}))
    text = forms.CharField(max_length=500, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Organise patient documents...'}))

    class Meta:
        model = ToDoList
        fields = ('name', 'text')
  #class generalform(forms.ModelForm):
    #name = forms.CharField(required=False)
    #age =forms.CharField(required=False)
    #Company = forms.CharField(required=False)

    #class Meta:
        #model = Post
        #fields = ('name', 'age') 


  #class Meta:
      #model = Post
 #fields = ('question1',)

  #class Meta:
    #model = Post
    #fields = ('post',)

#class UploadGDPRfileform(forms.Form):
    #title = forms.CharField(max_length=50)
    #file = forms.FileField()
