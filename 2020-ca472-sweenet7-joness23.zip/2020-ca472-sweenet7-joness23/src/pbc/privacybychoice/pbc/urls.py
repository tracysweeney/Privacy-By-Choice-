from django.conf.urls import url
from pbc import views
from django.contrib.auth import login

from django.urls import path

from .views import SurveyView, GeneratePDF, GeneralView

app_name = 'pbc'
urlpatterns = [
    url(r'^$', views.home, name='home'),
    url(r'^products/$', views.products, name='products'),
    url(r'^contact/$', views.contact, name='contact'),
    
    url(r'^login/$', views.user_login, name='login'),
    url(r'^signup/$', views.signup, name='signup'),

    url(r'^profile/$', views.view_profile, name='view_profile'),
    url(r'^change-password/$', views.change_password, name='change_password'),
    url(r'^profile/edit/$', views.edit_profile, name='edit_profile'),

    url(r'^profile/general/$', GeneralView.as_view(), name='general'),
    path(r'^delete/<todolist_id>$', views.delete, name='delete'),
    url(r'^profile/survey/$', SurveyView.as_view(), name='survey'),
    url(r'^profile/survey/requirements/$', views.requirements, name='requirements'),
    url(r'^profile/training/$', views.training, name='training'),
    url(r'^profile/upgrade-package/$', views.upgrade_package, name='upgrade_package'),
    url(r'^profile/pdffile/$', GeneratePDF.as_view(), name='pdffile'),


    url(r'^profile/dentalrecommendation/$', views.dentalrecommendation, name='dentalrecommendation'),
    url(r'^profile/gprecommendation/$', views.gprecommendation, name='gprecommendation'),
    url(r'^profile/solicitorrecommendation/$', views.solicitorrecommendation, name='solicitorrecommendation'),
    url(r'^profile/dentalrecommendation/automatedocs$', views.automatedocs, name='automatedocs'),
    url(r'^profile/training/overviewofgdpr/$', views.overviewofgdpr, name='overviewofgdpr'),
    url(r'^profile/training/rolesandresponsbilities/$', views.rolesandresponsbilities, name='rolesandresponsbilities'),
    url(r'^profile/training/medicaldata/$', views.medicaldata, name='medicaldata'),
    url(r'^profile/training/personaldata/$', views.personaldata, name='personaldata'),
    url(r'^profile/training/databreach/$', views.databreach, name='databreach'),
    
]
