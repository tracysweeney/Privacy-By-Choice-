from django.apps import AppConfig


class pbcConfig(AppConfig):
    name = 'pbc'
