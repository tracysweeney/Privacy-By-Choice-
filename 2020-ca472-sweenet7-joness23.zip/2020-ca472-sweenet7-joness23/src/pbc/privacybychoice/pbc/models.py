from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.db.models.signals import post_save

class Survey(models.Model):
	user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="survey", null=True)
	sector = models.CharField(max_length=500)
	company = models.CharField(max_length=500)
	name = models.CharField(max_length=500)
	employees_number = models.CharField(max_length=500)
	data_type = models.CharField(max_length=500)
	date = models.CharField(max_length=500)
	DPO = models.CharField(max_length=500)

	def __str__(self):
		return self.user.username

class UserProfile(models.Model):
	user = models.OneToOneField(User, on_delete=models.CASCADE)
	first_name = models.CharField(max_length=100, blank=True)
	last_name = models.CharField(max_length=100, blank=True)
	email = models.EmailField(max_length=100)
	email_confirmed = models.BooleanField(default=False)
	bio = models.TextField(max_length=500, blank=True)
	#signup_confirmation = models.BooleanField(default=False)

	def __str__(self):
		return self.user.username

def create_profile(sender, **kwargs):
	if kwargs['created']:
		user_profile = UserProfile.objects.create(user=kwargs['instance'])

post_save.connect(create_profile, sender=User)

class Notification(models.Model):
	title = models.CharField(max_length=256)
	message = models.TextField()
	viewed = models.BooleanField(default=False)
	user = models.ForeignKey(User, on_delete=models.CASCADE)

@receiver(post_save, sender=User)
def create_welcome_message(sender, **kwargs):
	if kwargs.get('created', False):
		Notification.objects.create(user=kwargs.get('instance'),
			title='Welcome to Privacy By Choice',
			message='Start your journey today by completing our user survey')

class ToDoList(models.Model):
	user = models.ForeignKey(User, on_delete=models.CASCADE)
	name = models.CharField(max_length=200)
	text = models.CharField(max_length=500, default='my to do item')
	#completed = models.BooleanField(default=False)

	def __str__(self):
		return self.user.username

	
	

#@receiver(post_save, sender=User)
#def update_user_profile(sender, instance, created, **kwargs):
    #if created:
        #Profile.objects.create(user=instance)
    #instance.profile.save()

#class Size(models.Model):
	#title = models.CharField(max_length=100)

	#def __str__(self):
		#return self.title

#class PBC(models.Model):
	#size = models.ForeignKey(Size, on_delete=models.CASCADE)
	#question1 = models.CharField(max_length=100)
	#question2 = models.CharField(max_length=100)
	#question3 = models.CharField(max_length=100)
