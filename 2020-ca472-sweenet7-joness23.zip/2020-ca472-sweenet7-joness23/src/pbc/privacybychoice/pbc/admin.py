from django.contrib import admin
#from .models import pbc, Size
from pbc.models import UserProfile, Survey, ToDoList

#admin.site.register(pbc)
#admin.site.register(Size)
admin.site.register(UserProfile)
admin.site.register(Survey)
admin.site.register(ToDoList)
#admin.site.site_header = 'Administration'

#class UserProfileAdmin(admin.ModelAdmin):
#	list_display = ('user', 'first_name', 'last_name', 'user_bio')

#	def user_bio(self, obj):
#		return obj.bio

#admin.site.register(UserProfile, UserProfileAdmin)